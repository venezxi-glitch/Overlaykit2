package app.overlaykit

import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

// Size values are fractions of the image height. Defaults were measured on one 2400x1080
// Showdown screenshot (enemy bar 96x14 px, red body 233,22,47) and must be rechecked on other modes.
data class DetectorConfig(
    val redMin: Int = 170,
    val gPct: Int = 58,
    val bPct: Int = 62,
    val minW: Float = 0.015f,
    val maxW: Float = 0.14f,
    val minH: Float = 0.008f,
    val maxH: Float = 0.026f,
    val minAspect: Float = 1.2f,
    val maxAspect: Float = 12f,
    val minFill: Float = 0.45f,
    val discMax: Float = 0.06f,
    val fullBarW: Float = 0.089f,
    val roiTop: Float = 0.05f,
    val roiBottom: Float = 0.98f,
    val boxWidthMul: Float = 1.2f,
    val boxHeightMul: Float = 1.5f,
    val boxGap: Float = 1f,
)

class Bar(
    val x0: Int, val x1: Int, val y0: Int, val y1: Int,
    val cx: Float, val hp: Float, val disc: Float,
)

class Target(
    val l: Float, val t: Float, val r: Float, val b: Float,
    val dist: Float, val hp: Float,
)

class DetectResult(val bars: List<Bar>, val candidates: Int, val boxesSkipped: Int)

private class Runs {
    var y = IntArray(256)
    var x0 = IntArray(256)
    var x1 = IntArray(256)
    var parent = IntArray(256)
    var n = 0

    fun add(yy: Int, s: Int, e: Int) {
        if (n == y.size) {
            val m = y.size * 2
            y = y.copyOf(m); x0 = x0.copyOf(m); x1 = x1.copyOf(m); parent = parent.copyOf(m)
        }
        y[n] = yy; x0[n] = s; x1[n] = e; parent[n] = n
        n++
    }

    fun find(a: Int): Int {
        var r = a
        while (parent[r] != r) {
            parent[r] = parent[parent[r]]
            r = parent[r]
        }
        return r
    }

    fun union(a: Int, b: Int) {
        val ra = find(a)
        val rb = find(b)
        if (ra != rb) parent[rb] = ra
    }
}

object Detector {
    private const val MAX_RUNS = 20000

    fun isRed(p: Int, c: DetectorConfig): Boolean {
        val r = (p shr 16) and 255
        val g = (p shr 8) and 255
        val b = p and 255
        return r >= c.redMin && g * 100 <= r * c.gPct && b * 100 <= r * c.bPct
    }

    /**
     * px is packed 0x00RRGGBB, size w*h, landscape (h is the short side).
     * Finds red health bars, then drops the ones that stand on the red ground disc of a
     * destructible box, because those bars look the same as enemy bars.
     */
    fun detect(px: IntArray, w: Int, h: Int, c: DetectorConfig): DetectResult {
        if (w <= 0 || h <= 0 || px.size < w * h) return DetectResult(emptyList(), 0, 0)
        val yStart = (h * c.roiTop).toInt().coerceIn(0, h)
        val yEnd = (h * c.roiBottom).toInt().coerceIn(yStart, h)

        val runs = Runs()
        var prevStart = 0
        var prevEnd = 0
        for (y in yStart until yEnd) {
            val curStart = runs.n
            val row = y * w
            var x = 0
            while (x < w) {
                if (!isRed(px[row + x], c)) { x++; continue }
                val s = x
                while (x < w && isRed(px[row + x], c)) x++
                if (runs.n >= MAX_RUNS) break
                runs.add(y, s, x - 1)
            }
            val curEnd = runs.n
            var i = prevStart
            var j = curStart
            while (i < prevEnd && j < curEnd) {
                if (runs.x0[i] <= runs.x1[j] && runs.x0[j] <= runs.x1[i]) runs.union(i, j)
                if (runs.x1[i] < runs.x1[j]) i++ else j++
            }
            prevStart = curStart
            prevEnd = curEnd
            if (runs.n >= MAX_RUNS) break
        }

        val n = runs.n
        val minX = IntArray(n) { Int.MAX_VALUE }
        val maxX = IntArray(n) { -1 }
        val minY = IntArray(n) { Int.MAX_VALUE }
        val maxY = IntArray(n) { -1 }
        val cnt = IntArray(n)
        for (i in 0 until n) {
            val r = runs.find(i)
            minX[r] = min(minX[r], runs.x0[i])
            maxX[r] = max(maxX[r], runs.x1[i])
            minY[r] = min(minY[r], runs.y[i])
            maxY[r] = max(maxY[r], runs.y[i])
            cnt[r] += runs.x1[i] - runs.x0[i] + 1
        }

        val fullW = c.fullBarW * h
        val bars = ArrayList<Bar>()
        var candidates = 0
        var skipped = 0
        for (r in 0 until n) {
            if (cnt[r] == 0) continue
            val bw = maxX[r] - minX[r] + 1
            val bh = maxY[r] - minY[r] + 1
            if (bw < c.minW * h || bw > c.maxW * h) continue
            if (bh < c.minH * h || bh > c.maxH * h) continue
            val aspect = bw.toFloat() / bh
            if (aspect < c.minAspect || aspect > c.maxAspect) continue
            if (cnt[r].toFloat() / (bw * bh) < c.minFill) continue
            candidates++
            // A damaged bar shrinks from the right, so the unit's center is the full bar's center.
            val cx = if (bw < 0.9f * fullW) minX[r] + fullW / 2f else (minX[r] + maxX[r] + 1) / 2f
            val disc = discScore(px, w, h, c, cx, maxY[r], max(bw.toFloat(), fullW))
            if (disc > c.discMax) { skipped++; continue }
            bars.add(Bar(minX[r], maxX[r], minY[r], maxY[r], cx, min(1f, bw / fullW), disc))
        }
        return DetectResult(bars, candidates, skipped)
    }

    private fun discScore(px: IntArray, w: Int, h: Int, c: DetectorConfig, cx: Float, bottom: Int, bw: Float): Float {
        val x0 = max(0, (cx - 0.65f * bw).toInt())
        val x1 = min(w, (cx + 0.65f * bw).toInt())
        val y0 = min(h, (bottom + 0.35f * bw).toInt())
        val y1 = min(h, (bottom + 1.75f * bw).toInt())
        if (x1 <= x0 || y1 <= y0) return 0f
        var red = 0
        for (y in y0 until y1) {
            val row = y * w
            for (x in x0 until x1) if (isRed(px[row + x], c)) red++
        }
        return red.toFloat() / ((x1 - x0) * (y1 - y0))
    }

    fun distance(l: Float, t: Float, r: Float, b: Float, aspect: Float, playerX: Float, playerY: Float): Float {
        val dx = ((l + r) / 2f - playerX) * aspect
        val dy = (t + b) / 2f - playerY
        return sqrt(dx * dx + dy * dy)
    }

    /** Boxes are placed below each bar. Distance is in screen heights. Sorted nearest first. */
    fun buildTargets(bars: List<Bar>, w: Int, h: Int, c: DetectorConfig, playerX: Float, playerY: Float): List<Target> {
        val aspect = w.toFloat() / h
        val fullW = c.fullBarW * h
        val boxW = fullW * c.boxWidthMul
        val boxH = fullW * c.boxHeightMul
        return bars.map { bar ->
            val top = bar.y1 + 1f + c.boxGap
            val l = (bar.cx - boxW / 2f) / w
            val r = (bar.cx + boxW / 2f) / w
            val t = top / h
            val b = (top + boxH) / h
            Target(l, t, r, b, distance(l, t, r, b, aspect, playerX, playerY), bar.hp)
        }.sortedBy { it.dist }
    }
}
