package app.overlaykit

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.SystemClock
import android.util.DisplayMetrics
import android.util.Log
import android.view.WindowManager
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

class CaptureService : Service() {

    companion object {
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        const val ACTION_STOP = "stop"
        private const val TAG = "OverlayKit"
        private const val CHANNEL = "capture"
        private const val NOTIF_ID = 1
        private const val FRAME_INTERVAL_MS = 66L
        private const val TARGET_HEIGHT = 540
    }

    private val thread = HandlerThread("capture").apply { start() }
    private val handler = Handler(thread.looper)
    private lateinit var wm: WindowManager
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var overlay: OverlayView? = null
    private var menu: MenuController? = null
    private val tracker = Tracker()
    private var capW = 0
    private var capH = 0
    private var lastFrame = 0L
    private var lastStats = 0L
    private var lastThumb = 0L
    private var frames = 0L
    private var lastError = ""
    private var px = IntArray(0)
    private var started = false
    private var released = false

    private val displayListener = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(id: Int) {}
        override fun onDisplayRemoved(id: Int) {}
        override fun onDisplayChanged(id: Int) { if (!released) buildCapture() }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        if (started) return START_NOT_STICKY

        val code = intent?.getIntExtra(EXTRA_CODE, 0) ?: 0
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) {
            intent?.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION") intent?.getParcelableExtra(EXTRA_DATA)
        }
        if (data == null) { stopSelf(); return START_NOT_STICKY }

        started = true
        Config.load(this)
        startAsForeground()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager

        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val p = mpm.getMediaProjection(code, data)
        projection = p
        p.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, handler)

        val ov = OverlayView(this)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT,
        )
        lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        wm.addView(ov, lp)
        overlay = ov

        val m = MenuController(this, wm, { Config.save(this) }, { stopSelf() })
        m.show()
        menu = m

        (getSystemService(DISPLAY_SERVICE) as DisplayManager).registerDisplayListener(displayListener, handler)
        buildCapture()
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Overlay Kit", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this, 0, Intent(this, CaptureService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, CHANNEL)
            .setContentTitle("Overlay Kit is running")
            .setContentText("Tap to stop")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentIntent(stop)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    @Synchronized
    private fun buildCapture() {
        val p = projection ?: return
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(dm)
        val w = dm.widthPixels
        val h = dm.heightPixels
        if (w <= 0 || h <= 0) return
        if (display != null && w == capW && h == capH) return
        capW = w; capH = h
        tracker.reset()

        val old = reader
        val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        r.setOnImageAvailableListener({ onFrame(it) }, handler)
        reader = r

        val d = display
        if (d == null) {
            display = p.createVirtualDisplay(
                "overlaykit", w, h, dm.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, handler
            )
        } else {
            d.resize(w, h, dm.densityDpi)
            d.surface = r.surface
        }
        old?.close()
    }

    private fun onFrame(r: ImageReader) {
        val img: Image? = try {
            r.acquireLatestImage()
        } catch (e: Exception) {
            lastError = "acquire: ${e.javaClass.simpleName}"
            null
        }
        if (img == null) return
        try {
            frames++
            val now = SystemClock.uptimeMillis()
            if (now - lastFrame < FRAME_INTERVAL_MS) return
            lastFrame = now

            val plane = img.planes[0]
            val buf = plane.buffer
            val rowStride = plane.rowStride
            val pixelStride = plane.pixelStride
            val shortSide = min(img.width, img.height)
            val step = max(1, (shortSide / TARGET_HEIGHT.toFloat()).roundToInt())
            val ow = img.width / step
            val oh = img.height / step
            if (ow <= 0 || oh <= 0) return
            if (px.size != ow * oh) px = IntArray(ow * oh)

            var lumaSum = 0L
            var lumaCount = 0
            for (y in 0 until oh) {
                val rowOff = y * step * rowStride
                for (x in 0 until ow) {
                    val o = rowOff + x * step * pixelStride
                    val rr = buf.get(o).toInt() and 255
                    val gg = buf.get(o + 1).toInt() and 255
                    val bb = buf.get(o + 2).toInt() and 255
                    px[y * ow + x] = (rr shl 16) or (gg shl 8) or bb
                    if (((x + y) and 15) == 0) { lumaSum += rr + gg + bb; lumaCount++ }
                }
            }
            val bright = if (lumaCount > 0) (lumaSum / (lumaCount * 3L)).toInt() else 0

            val cfg = Config.detector
            val result = Detector.detect(px, ow, oh, cfg)
            val targets = Detector.buildTargets(result.bars, ow, oh, cfg, Config.playerX, Config.playerY)
            val shown = tracker.update(targets, ow.toFloat() / oh, Config.playerX, Config.playerY)

            val dbg = if (Config.debug) {
                "src ${img.width}x${img.height}  frames $frames\n" +
                    "bright $bright  bars ${result.candidates}\n" +
                    "boxes skipped ${result.boxesSkipped}  shown ${shown.size}" +
                    if (lastError.isEmpty()) "" else "\n$lastError"
            } else ""
            overlay?.post { overlay?.update(shown, dbg) }

            if (now - lastStats > 400) {
                lastStats = now
                menu?.setCount(shown.size)
                if (Config.debug) menu?.setStats(dbg)
            }
            if (Config.debug && now - lastThumb > 600) {
                lastThumb = now
                menu?.setThumb(makeThumb(ow, oh))
            }
        } catch (e: Exception) {
            lastError = "${e.javaClass.simpleName}: ${e.message ?: ""}"
            Log.e(TAG, "frame failed", e)
        } finally {
            img.close()
        }
    }

    private fun makeThumb(ow: Int, oh: Int): Bitmap {
        val tw = 200
        val th = max(1, tw * oh / ow)
        val out = IntArray(tw * th)
        for (ty in 0 until th) {
            val sy = ty * oh / th
            for (tx in 0 until tw) {
                out[ty * tw + tx] = 0xFF000000.toInt() or px[sy * ow + tx * ow / tw]
            }
        }
        return Bitmap.createBitmap(out, tw, th, Bitmap.Config.ARGB_8888)
    }

    override fun onDestroy() {
        released = true
        try { (getSystemService(DISPLAY_SERVICE) as DisplayManager).unregisterDisplayListener(displayListener) } catch (_: Exception) {}
        menu?.hide()
        overlay?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        display?.release()
        reader?.close()
        projection?.stop()
        thread.quitSafely()
        super.onDestroy()
    }
}
