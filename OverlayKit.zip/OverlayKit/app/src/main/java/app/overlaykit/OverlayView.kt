package app.overlaykit

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.View
import kotlin.math.roundToInt

class OverlayView(ctx: Context) : View(ctx) {

    @Volatile private var targets: List<Target> = emptyList()
    @Volatile private var debugText: String = ""

    // Colors avoid red on purpose so the overlay is not detected by its own capture.
    private val boxPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 3f; color = 0xFF00E5FF.toInt()
    }
    private val lowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 5f; color = 0xFF76FF03.toInt()
    }
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 2.5f; color = 0xFFFFEA00.toInt()
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFFFFF.toInt(); textSize = 26f; setShadowLayer(4f, 0f, 0f, 0xFF000000.toInt())
    }
    private val warnPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 14f; color = 0xFFFF00FF.toInt()
    }
    private val dbgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFFFFF.toInt(); textSize = 24f; textAlign = Paint.Align.RIGHT
        setShadowLayer(5f, 0f, 0f, 0xFF000000.toInt())
    }

    fun update(t: List<Target>, dbg: String) {
        targets = t
        debugText = dbg
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()

        if (Config.debug) {
            val px = Config.playerX * w
            val py = Config.playerY * h
            c.drawLine(px - 14f, py, px + 14f, py, linePaint)
            c.drawLine(px, py - 14f, px, py + 14f, linePaint)
            var y = 60f
            for (line in debugText.split('\n')) {
                c.drawText(line, w - 24f, y, dbgPaint)
                y += 28f
            }
        }

        val t = targets
        if (t.isEmpty()) return

        if (Config.esp) {
            for (e in t) {
                val low = Config.lowHpMarker && e.hp < LOW_HP
                c.drawRect(e.l * w, e.t * h, e.r * w, e.b * h, if (low) lowPaint else boxPaint)
                c.drawText("%d%%  %.2f".format((e.hp * 100).roundToInt(), e.dist), e.l * w, e.b * h + 28f, textPaint)
            }
        }
        if (Config.tracer) {
            val n = t[0]
            c.drawLine(Config.playerX * w, Config.playerY * h, (n.l + n.r) / 2f * w, (n.t + n.b) / 2f * h, linePaint)
        }
        if (Config.proximityWarning && t[0].dist < Config.warnRadius) {
            c.drawRect(7f, 7f, w - 7f, h - 7f, warnPaint)
        }
    }

    private companion object {
        const val LOW_HP = 0.4f
    }
}
