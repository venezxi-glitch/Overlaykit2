package app.overlaykit

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.min

class MenuController(
    base: Context,
    private val wm: WindowManager,
    private val onChanged: () -> Unit,
    private val onStop: () -> Unit,
) {
    private val ctx = ContextThemeWrapper(base, android.R.style.Theme_DeviceDefault)
    private val accent = 0xFF7C5CFF.toInt()
    private val root = LinearLayout(ctx)
    private val scroll = ScrollView(ctx)
    private val panel = LinearLayout(ctx)
    private val countText = TextView(ctx)
    private val statsText = TextView(ctx)
    private val thumb = ImageView(ctx)
    private val lp = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
        PixelFormat.TRANSLUCENT,
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        x = dp(8); y = dp(60)
    }

    private fun dp(v: Int) = (v * ctx.resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radiusDp: Int, strokeColor: Int = 0) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radiusDp).toFloat()
        if (strokeColor != 0) setStroke(dp(1), strokeColor)
    }

    private fun toggle(label: String, initial: Boolean, set: (Boolean) -> Unit) = Switch(ctx).apply {
        text = label; isChecked = initial; setTextColor(Color.WHITE); textSize = 14f
        thumbTintList = ColorStateList.valueOf(accent)
        trackTintList = ColorStateList.valueOf(0x667C5CFF)
        setPadding(0, dp(6), 0, dp(6))
        setOnCheckedChangeListener { _, v -> set(v); onChanged() }
    }

    private fun fitPanel() {
        panel.measure(
            View.MeasureSpec.makeMeasureSpec(dp(230), View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
        )
        val dm = ctx.resources.displayMetrics
        val cap = (min(dm.widthPixels, dm.heightPixels) * 0.68f).toInt()
        val p = scroll.layoutParams
        p.height = min(panel.measuredHeight, cap)
        scroll.layoutParams = p
        if (root.isAttachedToWindow) wm.updateViewLayout(root, lp)
    }

    private fun applyDebugVisibility() {
        val v = if (Config.debug) View.VISIBLE else View.GONE
        statsText.visibility = v
        thumb.visibility = v
    }

    init {
        root.orientation = LinearLayout.VERTICAL

        val bubble = TextView(ctx).apply {
            text = "\u2630"; setTextColor(Color.WHITE); textSize = 20f; gravity = Gravity.CENTER
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(accent) }
            layoutParams = LinearLayout.LayoutParams(dp(46), dp(46))
        }

        panel.orientation = LinearLayout.VERTICAL
        panel.setPadding(dp(16), dp(14), dp(16), dp(14))

        val title = TextView(ctx).apply {
            text = "Overlay Kit"; setTextColor(Color.WHITE); textSize = 17f
            setTypeface(typeface, Typeface.BOLD)
        }
        countText.apply { text = "Enemies: 0"; setTextColor(0xFF9AA0B4.toInt()); textSize = 12f }

        statsText.apply {
            setTextColor(0xFFB8C0D8.toInt()); textSize = 11f; typeface = Typeface.MONOSPACE
            setPadding(0, dp(6), 0, dp(4))
        }
        thumb.apply {
            adjustViewBounds = true; scaleType = ImageView.ScaleType.FIT_CENTER
            setBackgroundColor(Color.BLACK)
        }

        val radiusLabel = TextView(ctx).apply {
            text = "Warning radius"; setTextColor(0xFF9AA0B4.toInt()); textSize = 12f
            setPadding(0, dp(8), 0, 0)
        }
        val radius = SeekBar(ctx).apply {
            max = 50; progress = (Config.warnRadius * 100).toInt()
            progressTintList = ColorStateList.valueOf(accent)
            thumbTintList = ColorStateList.valueOf(accent)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    Config.warnRadius = p / 100f
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) { onChanged() }
            })
        }
        val stop = Button(ctx).apply {
            text = "Stop"; setTextColor(Color.WHITE); isAllCaps = false
            background = rounded(0x33FFFFFF, 12)
            setOnClickListener { onStop() }
        }

        panel.addView(title)
        panel.addView(countText)
        panel.addView(toggle("ESP boxes", Config.esp) { Config.esp = it })
        panel.addView(toggle("Line to nearest enemy", Config.tracer) { Config.tracer = it })
        panel.addView(toggle("Low HP marker", Config.lowHpMarker) { Config.lowHpMarker = it })
        panel.addView(toggle("Proximity warning", Config.proximityWarning) { Config.proximityWarning = it })
        panel.addView(radiusLabel)
        panel.addView(radius)
        panel.addView(toggle("Debug info", Config.debug) {
            Config.debug = it
            applyDebugVisibility()
            fitPanel()
        })
        panel.addView(statsText)
        panel.addView(thumb, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ))
        panel.addView(stop, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(10) })

        scroll.background = rounded(0xF0151821.toInt(), 18, 0x33FFFFFF)
        scroll.visibility = View.GONE
        scroll.addView(panel, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        root.addView(bubble)
        root.addView(scroll, LinearLayout.LayoutParams(dp(230), LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) })
        applyDebugVisibility()

        bubble.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = e.rawX - sx; val dy = e.rawY - sy
                        if (abs(dx) > dp(6) || abs(dy) > dp(6)) moved = true
                        if (moved) {
                            lp.x = ox + dx.toInt(); lp.y = oy + dy.toInt()
                            wm.updateViewLayout(root, lp)
                        }
                    }
                    MotionEvent.ACTION_UP -> if (!moved) {
                        if (scroll.visibility == View.VISIBLE) {
                            scroll.visibility = View.GONE
                        } else {
                            fitPanel()
                            scroll.visibility = View.VISIBLE
                        }
                        wm.updateViewLayout(root, lp)
                    }
                }
                return true
            }
        })
    }

    fun show() = wm.addView(root, lp)

    fun hide() {
        try { wm.removeView(root) } catch (_: Exception) {}
    }

    fun setCount(n: Int) {
        countText.post { countText.text = "Enemies: $n" }
    }

    fun setStats(s: String) {
        statsText.post { statsText.text = s }
    }

    fun setThumb(b: Bitmap) {
        thumb.post { thumb.setImageBitmap(b) }
    }
}
