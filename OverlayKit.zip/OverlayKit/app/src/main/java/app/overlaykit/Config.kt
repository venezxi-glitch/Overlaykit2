package app.overlaykit

import android.content.Context

object Config {
    @Volatile var esp = true
    @Volatile var tracer = true
    @Volatile var proximityWarning = true
    @Volatile var lowHpMarker = true
    @Volatile var debug = false
    @Volatile var warnRadius = 0.25f // in screen heights

    // Where the local brawler sits on screen (normalized). Measured on one 2400x1080 screenshot.
    @Volatile var playerX = 0.5f
    @Volatile var playerY = 0.5f

    @Volatile var detector = DetectorConfig()

    private const val FILE = "overlaykit"

    fun load(ctx: Context) {
        val p = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        esp = p.getBoolean("esp", true)
        tracer = p.getBoolean("tracer", true)
        proximityWarning = p.getBoolean("proximity", true)
        lowHpMarker = p.getBoolean("lowhp", true)
        debug = p.getBoolean("debug", false)
        warnRadius = p.getFloat("warnRadius", 0.25f).coerceIn(0f, 0.5f)
    }

    fun save(ctx: Context) {
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit()
            .putBoolean("esp", esp)
            .putBoolean("tracer", tracer)
            .putBoolean("proximity", proximityWarning)
            .putBoolean("lowhp", lowHpMarker)
            .putBoolean("debug", debug)
            .putFloat("warnRadius", warnRadius)
            .apply()
    }
}
